
<div align="center">
<img src = 'https://github.com/Royhtml/EmuFlash-V10/raw/main/icon/icon.png'>
</div>

<div align="center">
   
# 🚀 在 Termux 中运行 .exe 文件

[![Termux](https://img.shields.io/badge/Termux-000000?style=for-the-badge&logo=termux&logoColor=white)](https://termux.com/)
[![Wine](https://img.shields.io/badge/Wine-FFD700?style=for-the-badge&logo=wine&logoColor=black)](https://www.winehq.org/)

A comprehensive guide on running Windows executable (.exe) files in Termux using Wine and other methods.

在 Termux 中使用 Wine 和其他方法运行 Windows 可执行文件 (.exe) 的完整指南。

</div>

<img src="https://github.com/Royhtml/EmuFlash-V10/raw/main/code/b2.png" width="100%"></td>

<table>
    <td><img src="https://github.com/Royhtml/EmuFlash-V10/raw/main/code/b3.png" width="100%"></td>
    <td><img src="https://github.com/Royhtml/EmuFlash-V10/raw/main/code/b4.png" width="100%"></td>
  </tr>
<tr>
    <td><img src="https://github.com/Royhtml/EmuFlash-V10/raw/main/code/b5.png" width="100%"></td>
    <td><img src="https://github.com/Royhtml/EmuFlash-V10/raw/main/code/b6.png" width="100%"></td>
  </tr>
</table>

## Running .exe Files | 运行 .exe 文件 Pypi Python Tutorials

<img src = "https://github.com/Royhtml/EmuFlash-V10/raw/main/repo/Roy.gif">

### Step 1: Install Python

```bash
https://www.python.org/ftp/python/3.14.2/python-3.14.2-amd64.exe 
```

### Step 2: Install EmuFlash

```bash
pip install emuflash
```

### Step 3: Run EmuFlash

```bash
emuflash
```

## 📋 Prerequisites | 前提条件

<td><img src="https://github.com/Royhtml/EmuFlash-V10/raw/main/code/b1.png" width="100%"></td>

### English
- Termux installed from [F-Droid](https://f-droid.org/en/packages/com.termux/) (recommended) or Google Play
- Stable internet connection
- At least 500MB free storage
- Android 7.0 or higher

### 中文
- 从 [F-Droid](https://f-droid.org/en/packages/com.termux/) (推荐) 或 Google Play 安装 Termux
- 稳定的网络连接
- 至少 500MB 可用存储空间
- Android 7.0 或更高版本

---

## 📥 Installation Methods | 安装方法

### Method 1: Using Wine (Recommended) | 方法 1: 使用 Wine (推荐)

#### English

<details>
<summary><b>Step-by-Step Installation</b></summary>

1. **Update and upgrade packages:**
   ```bash
   pkg update && pkg upgrade -y
   ```

2. **Install required dependencies:**
   ```bash
   pkg install -y git wget proot-distro
   ```

3. **Install a Linux distribution (Ubuntu recommended):**
   ```bash
   proot-distro install ubuntu
   ```

4. **Login to Ubuntu:**
   ```bash
   proot-distro login ubuntu
   ```

5. **Inside Ubuntu, update packages:**
   ```bash
   apt update && apt upgrade -y
   ```

6. **Install Wine:**
   ```bash
   apt install -y wine
   ```

7. **Verify installation:**
   ```bash
   wine --version
   ```
</details>

#### 中文

<details>
<summary><b>逐步安装指南</b></summary>

1. **更新和升级包:**
   ```bash
   pkg update && pkg upgrade -y
   ```

2. **安装必要的依赖:**
   ```bash
   pkg install -y git wget proot-distro
   ```

3. **安装 Linux 发行版 (推荐 Ubuntu):**
   ```bash
   proot-distro install ubuntu
   ```

4. **登录到 Ubuntu:**
   ```bash
   proot-distro login ubuntu
   ```

5. **在 Ubuntu 内更新包:**
   ```bash
   apt update && apt upgrade -y
   ```

6. **安装 Wine:**
   ```bash
   apt install -y wine
   ```

7. **验证安装:**
   ```bash
   wine --version
   ```
</details>

### Method 2: Using Box86/Box64 | 方法 2: 使用 Box86/Box64

#### English

<details>
<summary><b>For ARM devices</b></summary>

1. **Install requirements:**
   ```bash
   pkg install -y python git cmake
   ```

2. **Clone and build Box86:**
   ```bash
   git clone https://github.com/ptitSeb/box86
   cd box86
   mkdir build && cd build
   cmake .. -DTERMUX=1
   make -j4
   make install
   ```

3. **Install Wine:**
   ```bash
   pkg install wine -y
   ```
</details>

#### 中文

<details>
<summary><b>适用于 ARM 设备</b></summary>

1. **安装必要组件:**
   ```bash
   pkg install -y python git cmake
   ```

2. **克隆并构建 Box86:**
   ```bash
   git clone https://github.com/ptitSeb/box86
   cd box86
   mkdir build && cd build
   cmake .. -DTERMUX=1
   make -j4
   make install
   ```

3. **安装 Wine:**
   ```bash
   pkg install wine -y
   ```
</details>

---

## 🚀 Running .exe Files | 运行 .exe 文件

### English

<details>
<summary><b>Basic Execution</b></summary>

1. **Navigate to directory containing .exe file:**
   ```bash
   cd /path/to/your/file
   ```

2. **Run the .exe file:**
   ```bash
   wine filename.exe
   ```

3. **For GUI applications, you might need:**
   ```bash
   pkg install x11-repo -y
   pkg install termux-x11-nightly -y
   ```
</details>

<details>
<summary><b>Common Commands</b></summary>

- **Check Wine configuration:**
  ```bash
  winecfg
  ```

- **Install Windows DLLs/components:**
  ```bash
  winetricks
  ```

- **Run Windows program installer:**
  ```bash
  wine msiexec /i installer.msi
  ```

- **Create Wine prefix (virtual Windows environment):**
  ```bash
   WINEARCH=win32 WINEPREFIX=~/win32 winecfg
  ```
</details>

### 中文

<details>
<summary><b>基本执行方法</b></summary>

1. **导航到包含 .exe 文件的目录:**
   ```bash
   cd /path/to/your/file
   ```

2. **运行 .exe 文件:**
   ```bash
   wine filename.exe
   ```

3. **对于 GUI 应用程序，可能需要:**
   ```bash
   pkg install x11-repo -y
   pkg install termux-x11-nightly -y
   ```
</details>

<details>
<summary><b>常用命令</b></summary>

- **检查 Wine 配置:**
  ```bash
  winecfg
  ```

- **安装 Windows DLLs/组件:**
  ```bash
  winetricks
  ```

- **运行 Windows 程序安装器:**
  ```bash
  wine msiexec /i installer.msi
  ```

- **创建 Wine 前缀 (虚拟 Windows 环境):**
  ```bash
   WINEARCH=win32 WINEPREFIX=~/win32 winecfg
  ```
</details>

---

## ⚙️ Configuration Tips | 配置提示

### English

<details>
<summary><b>Optimization Settings</b></summary>

1. **Set Wine architecture (for 32-bit apps):**
   ```bash
   export WINEARCH=win32
   export WINEPREFIX=~/win32
   ```

2. **Enable virtual desktop (for GUI apps):**
   ```bash
   winecfg
   ```
   Then go to Graphics tab → Enable Virtual Desktop

3. **Install essential components:**
   ```bash
   apt install -y winetricks
   winetricks corefonts vcrun6 dotnet48
   ```
</details>

<details>
<summary><b>Troubleshooting</b></summary>

- **"wine: cannot find 'filename.exe'":**
  Ensure you're in the correct directory or provide full path

- **"Cannot open display":**
  Install and start Termux:X11 addon

- **Missing DLL errors:**
  Use `winetricks` to install required DLLs

- **Low memory errors:**
  Close other apps and use swap if available
</details>

### 中文

<details>
<summary><b>优化设置</b></summary>

1. **设置 Wine 架构 (用于 32 位应用):**
   ```bash
   export WINEARCH=win32
   export WINEPREFIX=~/win32
   ```

2. **启用虚拟桌面 (用于 GUI 应用):**
   ```bash
   winecfg
   ```
   然后转到 Graphics 标签页 → 启用 Virtual Desktop

3. **安装必要组件:**
   ```bash
   apt install -y winetricks
   winetricks corefonts vcrun6 dotnet48
   ```
</details>

<details>
<summary><b>故障排除</b></summary>

- **"wine: cannot find 'filename.exe'":**
  确保在正确的目录或提供完整路径

- **"Cannot open display":**
  安装并启动 Termux:X11 插件

- **缺少 DLL 错误:**
  使用 `winetricks` 安装所需的 DLLs

- **内存不足错误:**
  关闭其他应用程序，如果可用则使用交换空间
</details>

---

## 📁 Directory Structure | 目录结构

### English
```
Termux Home/
├── storage/
│   └── shared/          # Android shared storage
├── win32/              # 32-bit Wine prefix (if created)
├── .wine/              # Default Wine prefix
└── Downloads/          # Your downloaded files
```

### 中文
```
Termux 主目录/
├── storage/
│   └── shared/          # Android 共享存储
├── win32/              # 32位 Wine 前缀 (如果已创建)
├── .wine/              # 默认 Wine 前缀
└── Downloads/          # 下载的文件
```

---

## 🚫 Limitations | 限制

### English
- ❌ Not all Windows applications are compatible
- ❌ Performance may be slower than native Windows
- ❌ DirectX 10/11/12 games may not work properly
- ❌ Anticheat software (EAC, BattlEye) will not work
- ❌ Requires sufficient storage and RAM

### 中文
- ❌ 并非所有 Windows 应用程序都兼容
- ❌ 性能可能比原生 Windows 慢
- ❌ DirectX 10/11/12 游戏可能无法正常工作
- ❌ 反作弊软件 (EAC, BattlEye) 将无法工作
- ❌ 需要足够的存储空间和 RAM

---

## 🔧 Advanced Usage | 高级用法

### English

<details>
<summary><b>Creating Desktop Shortcuts</b></summary>

1. **Create .desktop file:**
   ```bash
   nano ~/.local/share/applications/myapp.desktop
   ```

2. **Add content:**
   ```ini
   [Desktop Entry]
   Name=My Application
   Exec=wine /path/to/app.exe
   Type=Application
   Categories=Utility;
   ```

3. **Make executable:**
   ```bash
   chmod +x ~/.local/share/applications/myapp.desktop
   ```
</details>

<details>
<summary><b>Using Different Wine Versions</b></summary>

1. **Download Wine from Termux repository:**
   ```bash
   pkg install wine -y
   ```

2. **Or compile from source:**
   ```bash
   git clone https://github.com/wine-mirror/wine
   cd wine
   ./configure
   make
   ```
</details>

### 中文

<details>
<summary><b>创建桌面快捷方式</b></summary>

1. **创建 .desktop 文件:**
   ```bash
   nano ~/.local/share/applications/myapp.desktop
   ```

2. **添加内容:**
   ```ini
   [Desktop Entry]
   Name=我的应用程序
   Exec=wine /path/to/app.exe
   Type=Application
   Categories=Utility;
   ```

3. **设置为可执行:**
   ```bash
   chmod +x ~/.local/share/applications/myapp.desktop
   ```
</details>

<details>
<summary><b>使用不同 Wine 版本</b></summary>

1. **从 Termux 仓库下载 Wine:**
   ```bash
   pkg install wine -y
   ```

2. **或从源代码编译:**
   ```bash
   git clone https://github.com/wine-mirror/wine
   cd wine
   ./configure
   make
   ```
</details>

---

## 📚 Useful Resources | 有用资源

### English
- [WineHQ Official Website](https://www.winehq.org/)
- [Termux Wiki](https://wiki.termux.com/)
- [Box86 GitHub](https://github.com/ptitSeb/box86)
- [Winetricks GitHub](https://github.com/Winetricks/winetricks)

### 中文
- [WineHQ 官方网站](https://www.winehq.org/)
- [Termux Wiki](https://wiki.termux.com/)
- [Box86 GitHub](https://github.com/ptitSeb/box86)
- [Winetricks GitHub](https://github.com/Winetricks/winetricks)

---

## ⚠️ Disclaimer | 免责声明

### English
This guide is for educational purposes only. Running Windows applications on Android through Termux may violate software licenses. Only run applications you own or have permission to use. The developers are not responsible for any misuse or damage caused by following this guide.

### 中文
本指南仅用于教育目的。通过 Termux 在 Android 上运行 Windows 应用程序可能违反软件许可协议。仅运行您拥有或有权使用的应用程序。开发者不对因遵循本指南造成的任何误用或损害负责。

---

## 🌟 Support | 支持

If you found this guide helpful, consider:
如果本指南对您有帮助，请考虑:

- ⭐ Starring this repository | 给本仓库点星
- 🐛 Reporting issues | 报告问题
- 🔄 Contributing improvements | 贡献改进

**Happy coding! | 编程愉快！** 🎉

---

## 🕹️ Supported Systems / 支持的系统

| System / 系统 | Status / 状态 | Recommended Settings / 推荐设置 |
|--------------|---------------|--------------------------------|
| NES / FC | ✅ Excellent | Default |
| SNES / SFC | ✅ Excellent | xBRZ 2x Filter |
| Game Boy / GBC | ✅ Excellent | LCD Filter |
| Game Boy Advance | ✅ Excellent | 2x Resolution |
| PlayStation 1 | ✅ Great | Enhanced Resolution |
| Nintendo 64 | ⚠️ Good | Vulkan Renderer |
| Sega Genesis | ✅ Excellent | CRT Shader |
| PlayStation Portable | ✅ Good | 2x PSP Resolution |

## 🌟 Features / 主要功能
- **Multi-Input Support** / **多输入设备支持**
  - Gamepad/Controller (XInput & DirectInput) / 游戏手柄支持（XInput和DirectInput）
  - Keyboard & Mouse / 键盘和鼠标
  - Customizable keybindings / 可自定义按键映射
  - Input remapping on-the-fly / 实时输入重映射

- **Multi-Platform Emulation** / **多平台模拟**
  - Supports multiple console generations / 支持多代游戏主机
  - Save state functionality / 即时存档功能
  - Cheat code support / 金手指支持
  - High compatibility rate / 高兼容性

- **User-Friendly Interface** / **用户友好界面**
  - Modern GUI with dark/light themes / 现代化GUI，支持深色/浅色主题
  - Game library management / 游戏库管理
  - Screenshot and recording tools / 截图和录制工具
  - Performance customization / 性能自定义

## 📥 Installation / 安装指南

### Windows / Windows系统
1. Download the latest installer from [Releases](https://github.com/yourusername/emuflash/releases)
2. Run `EmuFlash_Setup.exe`
3. Follow the installation wizard
4. Launch EmuFlash from Start Menu or desktop shortcut

### Linux / Linux系统
```bash
# Ubuntu/Debian
sudo apt install ./emuflash.deb

# Arch Linux
sudo pacman -U emuflash.pkg.tar.zst

# AppImage
chmod +x EmuFlash.AppImage
./EmuFlash.AppImage
```

### macOS / macOS系统
1. Download `EmuFlash.dmg`
2. Open the disk image
3. Drag EmuFlash to Applications folder
4. Run from Launchpad or Applications

## 🎮 Input Configuration / 输入配置

### Gamepad Setup / 手柄设置
1. Connect your gamepad (Xbox, PlayStation, or generic controllers)
2. Open **Settings > Input Configuration**
3. Select your controller from the dropdown
4. Map buttons by clicking each function and pressing the corresponding button
5. Test input in the testing area

### Keyboard & Mouse Setup / 键盘和鼠标设置
1. Go to **Settings > Keyboard Configuration**
2. Choose between:
   - **Preset Profiles**: WASD, Arrow Keys, Numpad
   - **Custom Mapping**: Click to assign any key
3. Adjust mouse sensitivity for light gun games
4. Save your profile for different game types

### Multiple Controller Support / 多手柄支持
- Up to 4 simultaneous controllers
- Mix and match different controller types
- Assign different input schemes per player


### Turbo Mode / Turbo模式
- Adjustable turbo speed (1-30Hz)
- Per-button turbo configuration
- Visual turbo indicator

### Macros / 宏设置
- Record button sequences
- Assign to single button
- Loop and timing control

## 🖥️ System Requirements / 系统需求

### Minimum / 最低配置
- **OS**: Windows 10, Ubuntu 20.04, macOS 10.15
- **CPU**: Dual-core 2.0 GHz
- **RAM**: 4 GB
- **GPU**: OpenGL 3.3 compatible
- **Storage**: 500 MB free space

### Recommended / 推荐配置
- **OS**: Windows 11, Ubuntu 22.04, macOS 12
- **CPU**: Quad-core 3.0 GHz
- **RAM**: 8 GB
- **GPU**: Vulkan 1.2 compatible, 2 GB VRAM
- **Storage**: 2 GB free space for games

## 🎯 Quick Start / 快速开始

### First Run / 首次运行
1. Launch EmuFlash
2. Configure your input devices
3. Set up game directories in **Settings > Paths**
4. Scan for games
5. Double-click a game to start playing!

### Gamepad Tips / 手柄使用技巧
- Press **Start + Select** for quick menu
- **L3 + R3** toggles turbo mode
- Hold **Start** for 3 seconds to switch controller slots

### Keyboard Shortcuts / 键盘快捷键
| Shortcut / 快捷键 | Action / 功能 |
|------------------|---------------|
| F1 | Quick Save |
| F2 | Quick Load |
| F3 | Save State Menu |
| F4 | Load State Menu |
| F5 | Pause/Resume |
| F6 | Screenshot |
| F11 | Toggle Fullscreen |
| ESC | Menu |
| Tab | Fast Forward |

## 🔄 Updates / 更新

### Auto-Updater / 自动更新
EmuFlash checks for updates on launch. To manually check:
1. Go to **Help > Check for Updates**
2. Download and install new version
3. Restart EmuFlash

### Version History / 版本历史
See [CHANGELOG.md](CHANGELOG.md) for detailed version history.

## ❓ Troubleshooting / 故障排除

### Gamepad Not Detected / 手柄无法识别
1. Ensure controller is properly connected
2. Try different USB port
3. Update controller drivers
4. Check **Settings > Input > Refresh Devices**
5. Try generic XInput or DirectInput mode

### Input Lag / 输入延迟
1. Enable **Settings > Video > V-Sync**
2. Try different renderers (OpenGL, Vulkan, Direct3D)
3. Reduce audio latency in audio settings
4. Disable post-processing filters

### Performance Issues / 性能问题
1. Lower resolution scale
2. Disable shaders
3. Close background applications
4. Update graphics drivers

## 🤝 Contributing / 贡献指南

We welcome contributions! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for details.

### Reporting Issues / 报告问题
1. Check existing issues
2. Use the issue template
3. Include system specifications
4. Provide steps to reproduce

### Feature Requests / 功能请求
Submit suggestions through GitHub Issues with the "enhancement" label.

## 📄 License / 许可证

EmuFlash is licensed under the GPLv3 License. See [LICENSE](LICENSE) for details.


**The Smallest Flash Game Manager - No Ads**

![EmuFlash Manager](Screenshot_2026-01-11_141622.png)

---

## 📱 **EmuFlash 10.0 - Flash & Android Version**

**Made by:** Dwi Bakti & Dev  
**Version:** 10.0 Micro Edition  
**Size:** Only **5 MB** (Windows) / **8 MB** (Android)

**100% NO ADS** - Other flash emulators show ads every 2 minutes!

---

## ⚡ **Size Comparison - Smallest Ever**

| Emulator | Windows Size | Android Size | Has Ads? |
|----------|--------------|--------------|----------|
| **EmuFlash 10.0** | **5 MB** | **8 MB** | ❌ **NO** |
| Flash Player Pro | 25 MB | 15 MB | ✅ YES |
| Super Flash Game | 50 MB | 20 MB | ✅ YES |
| Flash Game Hub | 40 MB | 18 MB | ✅ YES |
| Old Flash Player | 15 MB | 12 MB | ✅ YES |

---

## ⚡ **Why EmuFlash 10.0 is Lighter & Better**

| Feature | EmuFlash 10.0 | RetroArch | PCSX2 | Dolphin |
|---------|---------------|-----------|-------|---------|
| **Install Size** | **15 MB** | 200+ MB | 100+ MB | 50+ MB |
| **RAM Usage** | **<50 MB** | 300+ MB | 500+ MB | 1 GB+ |
| **Windows XP** | ✅ **Yes** | ❌ No | ❌ No | ❌ No |
| **Launch Time** | **2 seconds** | 10+ seconds | 8+ seconds | 6+ seconds |
| **Setup Complexity** | **Click & Play** | Complex setup | BIOS needed | Hard config |

---

## 🚀 **Super Light Features**

### 1. **Instant Launch**
- Opens in 2 seconds even on Pentium 4
- No heavy libraries or dependencies

### 2. **Basic But Complete**
- **Search Games** – Find games fast
- **Games List** – Simple text-based view
- **Play/Stop** – One-click control
- **Fullscreen** – F4 shortcut

### 3. **XP & Old PC Ready**
- Works on Windows 2000/XP/Vista/7
- Needs only **DirectX 9** (from 2002)
- No .NET Framework required

### 4. **Game Management**
- Add ROMs via drag & drop
- Edit covers & info
- Category tagging

---

## 📖 **How to Use – Simple Steps**

### **1. Add Games**
- Drag ROM files into the Games List
- Or click "Edit Info" → "Add Game"

### **2. Play**
1. Click game in list
2. Click **"Play"** button
3. Use **"Fullscreen"** if wanted

### **3. Change Settings**
- "80%" = Screen size
- "Edit Cover" = Change picture
- "Category" = Organize games

### **4. Exit**
- Click **"Stop"** then close window
- No background processes left

---

## 💾 **System Requirements**

- **OS:** Windows 2000/XP/Vista/7/8/10/11
- **CPU:** Pentium III 500 MHz or higher
- **RAM:** 128 MB minimum
- **Storage:** 20 MB free space
- **GPU:** Any with DirectX 9 support

---

## 🌐 **Multi-Language**

**English:**
- "Play" = Start game
- "Stop" = End game
- "Fullscreen" = Big screen mode

**中文 (Chinese):**
- "运行" = 开始游戏
- "停止" = 结束游戏
- "全屏" = 全屏模式

---

## ✅ **Advantages Over Others**

### **VS RetroArch:**
- EmuFlash: 15 MB ↔ RetroArch: 200 MB
- EmuFlash: Works on XP ↔ RetroArch: Needs Win7+
- EmuFlash: Simple UI ↔ RetroArch: Confusing menus

### **VS Standalone Emulators:**
- No separate emulator for each console
- One manager for NES, SNES, Genesis, GBA
- Unified game library

### **VS Modern Managers:**
- No updates forcing new Windows
- No telemetry or data collection
- Runs on 20-year-old computers

---

## 🔧 **Made For Everyone By**

**Dwi Bakti & Dev**  
*Keeping old PCs alive with retro gaming.*


## 🎮 **What Makes EmuFlash 10.0 Special**

### **1. Tiny Size - Big Features**
- Windows: **5 MB only** (others 25-50 MB)
- Android: **8 MB only** (others 15-20 MB)
- Loads in **1 second**

### **2. Zero Ads - Pure Gaming**
- No banner ads
- No video ads
- No pop-ups
- No "watch ad to continue"

### **3. Built-in Game Downloader**
- Click "Search games..."
- Find 1000+ flash games
- Download directly in app
- Offline play available

### **4. Android Version Available**
- Same light design
- Touch controls
- Save game progress
- Background music control

---

## 📲 **Android Version Features**

### **Touch Controls:**
```
   [▲]                [A]
[◀]  [▶]          [B]   [O]            
   [▼]                [X]          
                     
```

### **Special Features:**
- Battery saving mode
- Screen orientation lock
- Quick save/load
- Controller support (Bluetooth)

---

## 🆓 **Game Download System**

**Free Games Included:**
1. **Puzzle Games** - 200+ titles
2. **Action Games** - 300+ titles  
3. **Arcade Games** - 150+ titles
4. **Educational** - 100+ titles
5. **Classic Flash** - 250+ titles

**How to Download:**
1. Click "Search games..."
2. Type game name
3. Click download button
4. Play instantly

---

## 💾 **System Requirements**

### **Windows Version:**
- OS: Windows XP to Windows 11
- RAM: 64 MB minimum
- Storage: 10 MB free
- CPU: Pentium II 300 MHz

### **Android Version:**
- OS: Android 4.0 to Android 14
- RAM: 128 MB minimum  
- Storage: 20 MB free
- Screen: 320x480 minimum

---

## 🚀 **How to Use - Simple**

### **1. Download & Install**
```
Windows: Download 5 MB .exe file → Run
Android: Download 8 MB .apk file → Install
```

### **2. Get Games**
- Click "Search games..."
- Browse categories
- Download free games
- Or add your own SWF files

### **3. Play & Save**
- Click game → Click "Play"
- Use keyboard/touch controls
- Save progress automatically
- Resume anytime

---

## ⭐ **Why Choose EmuFlash 10.0?**

### **vs Other Flash Emulators:**
✅ **5x Smaller** than competitors  
✅ **No Ads** - others have annoying ads  
✅ **Built-in Games** - no need separate downloads  
✅ **Works Offline** - download once, play forever  
✅ **Old PC Support** - runs on Windows XP easily  

### **Unique Features:**
- Game progress saving
- Custom controls
- Screenshot capture
- Game speed control
- Cheat code support

---

## 📥 **Download Versions**

### **Windows (5 MB):**
```
Portable Version: EmuFlash.exe --NoAds
```

### **Android (8 MB):**
```
APK File: EmuFlash.apk --NoAds
Google Play: Coming Soon
```

---

## 🆓 **Free Game Library Included**

**Pre-loaded Games:**
- Pac-Man Flash
- Tetris Battle
- Super Mario Flash
- 1942 Air Strike
- Puzzle Bobble
- 50+ more ready to play

**Total Available:** 1000+ flash games
**Download Size:** Each game 1-10 MB
**Update:** Weekly new games added

---

## 🔧 **Made For Gamers By**

**Dwi Bakti & Dev**  
*Bringing back flash games without the ads.*

---

## ❓ **FAQ**

**Q: Really no ads?**  
A: Yes! 100% ad-free forever.

**Q: Works on Windows XP?**  
A: Yes! Perfect for old PCs.

**Q: Android version free?**  
A: Yes! Same no-ads version.

**Q: New games added?**  
A: Every week, automatically.

**Q: Internet needed?**  
A: Only for downloading games. Play offline after.

---

**Status: Ready**  
**Games Available: 1000+**  
**Ads: None**  

---

*Perfect for: Old PCs, low-end phones, flash game lovers, ad-haters, quick gaming sessions.*


<div align="center">
  
**Made with ❤️ for Termux community**  
**为 Termux 社区用心制作**

[![Termux](https://img.shields.io/badge/Termux-000000?style=flat&logo=termux&logoColor=white)](https://termux.com/)
[![Wine](https://img.shields.io/badge/Wine-FFD700?style=flat&logo=wine&logoColor=black)](https://www.winehq.org/)
[![Android](https://img.shields.io/badge/Android-3DDC84?style=flat&logo=android&logoColor=white)](https://www.android.com/)

</div>

