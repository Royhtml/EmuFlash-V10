# emuflash/cli.py
from .gui import run_gui


def main():
    run_gui()


if __name__ == "__main__":
    main()
